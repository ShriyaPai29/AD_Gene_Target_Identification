library(ggplot2)
library(ggrepel)
library(dplyr)

name1 <- read.csv('obdiabvscont.tsv',sep='\t')
#name1 <- read.csv('PAH.tsv',sep='\t')
#name1 <- read.csv('Diabetes.tsv',sep='\t')
head(name1)
colnames(name1)

name1$DiffExpressed <- "Not Significant"
head(name1)
dim(name1)

#name1$DiffExpressed[name1$logFC>0 & name1$adj.P.Val<1] <- "Up-Regulated"
#name1$DiffExpressed[name1$logFC<0 & name1$adj.P.Val<1] <- "Down-Regulated"
name1$DiffExpressed[name1$logFC>0 & name1$PValue<0.05] <- "Up-Regulated"
name1$DiffExpressed[name1$logFC<0 & name1$PValue<0.05] <- "Down-Regulated"

head(name1)

name1$delabel <- NA

#head(arrange(name1,PValue),30)$PValue

thresh=head(arrange(name1,PValue),30)$PValue[30]

#head(arrange(name1,PValue),30)$GeneSymbol

name1$delabel[name1$PValue<=thresh]<-(name1$GeneSymbol[name1$PValue<=thresh])
#head(arrange(name1,PValue),30)

options(ggrepel.max.overlaps = 10)


ggplot(data = name1,aes(x=logFC,y=-log10(PValue),col=DiffExpressed,label=delabel))+
  ggtitle("Diabetes Differential Expression")+
  #theme(plot.title = element_text(hjust=0.5))+
 # geom_point()+
  geom_point(size = 2/5)+
  theme_minimal()+
  geom_text_repel()+
  #geom_label_repel(label.size=0.15)+
  scale_color_manual(values=c('dodgerblue3','gray50','firebrick3'))+
  #geom_vline(xintercept=c(-0.05,0.05),col='black')+
  #geom_hline(yintercept=c(-log10(0.001)),col='black')+
  theme(text=element_text(size=10))

